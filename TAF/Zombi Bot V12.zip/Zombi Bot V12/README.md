# Zombi Bot v12
# If u have problem in BOT
# Contact me ?
# Email : nedjworgan@gmail.com
# ICQ: 744289868
# My Facebook Page: https://www.facebook.com/viper1337official/

Install Xammp for run Other Tools :)
Install Python 3.0 for run Checker Valid Apple

Module :

-pip3 install -r requirements.txt

[Zombi Bot V12  - Only work for python 2.7]

Module :

-pip install request
-pip install requests
-pip install colorama
-pip install bs4

Thanks you~

