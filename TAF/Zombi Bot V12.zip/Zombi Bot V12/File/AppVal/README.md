# Apple Email Checker

Tool to check the email list registered on Apple or not. Originally made with php but changed to a more powerful python language.

## Requirement

- Python 3
- Requests

## How to run

install dependencies :

    pip3 install -r requirements.txt

run :

    python3 run.py

## Screenshot

![](screenshot/3.0.png)
