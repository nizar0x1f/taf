# Zombi Bot v13
# If u have problem in BOT
# Contact me ?
# Email : nedjworgan@gmail.com
# ICQ: 744289868
# My Facebook Page: https://www.facebook.com/viper1337official/

Install Xammp for Run Sender :)
Install Python 2.7 Run Other Tools

Module :

-pip3 install -r requirements.txt

[Zombi Bot V13  - Only work for python 2.7]

Module :
-pkg install bash
-pip install request
-pip install requests
-pip install colorama
-pip install bs4
-pip install tldextract

Thanks you~

